#!/bin/bash
# auto-approve.sh - 白名單自動允許常見操作（僅在 skill worktree 中生效）

# ── 只在 skill worktree 開發流程中觸發 ──────────────────
# 檢查：當前目錄名稱符合 skill-task-* 或 git branch 為 skill/*
CURRENT_DIR=$(basename "$PWD")
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)

if [[ "$CURRENT_DIR" != skill-task-* ]] && [[ "$CURRENT_BRANCH" != skill/* ]]; then
  # 不在 skill worktree → 不介入，讓 Claude Code 正常跳確認
  exit 0
fi

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // empty')
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty')

# ── 白名單 Tool 類型 ──────────────────────────────────
ALLOWED_TOOLS=("Write" "Edit" "MultiEdit" "Read" "Glob" "Grep" "LS" "TodoWrite" "TodoRead")

for allowed in "${ALLOWED_TOOLS[@]}"; do
  if [[ "$TOOL" == "$allowed" ]]; then
    echo '{"hookSpecificOutput": {"hookEventName": "PermissionRequest", "permissionDecision": "allow"}}'
    exit 0
  fi
done

# ── 白名單 Bash patterns ──────────────────────────────
if [[ "$TOOL" == "Bash" ]]; then
  SAFE_PATTERNS=(
    "^git (add|commit|checkout|branch|merge|rebase|push|pull|fetch|status|log|diff|worktree|stash)"
    "^npm (install|run|test|build|ci)"
    "^yarn " "^pnpm " "^bun "
    "^python[3]? " "^pip[3]? "
    "^mkdir" "^cp" "^mv" "^cat"
    "^echo" "^ls" "^find" "^grep"
    "^sed" "^awk" "^jq"
    "^chmod" "^touch" "^cd "
    "^pwd" "^which" "^env"
    "^node " "^npx "
  )

  for pattern in "${SAFE_PATTERNS[@]}"; do
    if echo "$COMMAND" | grep -qE "$pattern"; then
      echo '{"hookSpecificOutput": {"hookEventName": "PermissionRequest", "permissionDecision": "allow"}}'
      exit 0
    fi
  done
fi

# 不在白名單 → 讓 Claude Code 正常跳確認
exit 0

#!/bin/bash
# block-danger.sh - 永遠阻擋危險操作

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // empty')
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty')

[[ "$TOOL" != "Bash" ]] && exit 0

DANGER_PATTERNS=(
  "rm -rf /"
  "rm -rf ~"
  "rm -rf \$HOME"
  ":(){ :|:& };:"
  "curl.*\| *(bash|sh)"
  "wget.*\| *(bash|sh)"
)

for pattern in "${DANGER_PATTERNS[@]}"; do
  if echo "$COMMAND" | grep -qE "$pattern"; then
    echo "🚫 Blocked dangerous command: $COMMAND" >&2
    exit 2
  fi
done

exit 0

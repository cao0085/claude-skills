#!/bin/bash
# notify-done.sh - 完成後發 Windows Toast 通知

INPUT=$(cat)
STOP_REASON=$(echo "$INPUT" | jq -r '.stop_reason // "completed"')

# Windows Toast 通知（從 WSL 呼叫 PowerShell）
powershell.exe -NoProfile -Command "
  Add-Type -AssemblyName System.Windows.Forms
  \$n = New-Object System.Windows.Forms.NotifyIcon
  \$n.Icon = [System.Drawing.SystemIcons]::Information
  \$n.Visible = \$true
  \$n.ShowBalloonTip(6000, 'Claude Code 完成 ✅', '${STOP_REASON}', [System.Windows.Forms.ToolTipIcon]::Info)
  Start-Sleep -Milliseconds 6500
  \$n.Dispose()
" 2>/dev/null &

# Log
echo "[$(date '+%Y-%m-%d %H:%M:%S')] stop_reason: $STOP_REASON" >> "$HOME/.claude/done.log"

exit 0
